// Re-export DashboardLayout for backward compatibility
import DashboardLayout from "@/components/DashboardLayout";
export default DashboardLayout;

